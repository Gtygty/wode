angular
	.module('app.controllers', [])
	.controller('mainCtrl',['$scope', 'navData' function($scope, navData){

		


	}])